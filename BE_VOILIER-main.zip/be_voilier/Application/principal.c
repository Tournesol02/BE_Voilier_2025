#include <stm32f10x.h>
#include <stdio.h>
#include "Horloge.h"
#include "Accelerometre.h"
#include "Girouette.h"
#include "Servo.h"
#include "MyUart.h"
#include "Plateau.h"
#include "I2C.h"
#include "RTC.h"
#include "ADC.h"

//Variables
int angleVentVar;
int angleVoileVar;
volatile uint32_t moy;

void pilotage(volatile int commande) {
  Update_Motor_PWM(commande,TIM3,3);
};

int main (void) {
	// ---- Setup ------
  // Servo.c
  initServo(TIM4, 3);

  // Giroutte.c
  configEncoder(TIM2);
  LocaliserZero();

  // Test de lecture ADC
	My_USART_Config(USART1, 7500);
	initADC();
	
	// Init moyenne glissante
	int i = 0;
	uint32_t moyenne[LONGUEUR_MOY];
	for (int p = 0; p<LONGUEUR_MOY; p++){moyenne[p]=0xFFFF;}
  uint32_t sum;
	
  //init Uart
	My_USART_Config(USART1, 7500); //call with baudrate which is one over this value times clock frequency
	USART_IT_Receive_Enable(USART1);
	USART_Send_String(USART1,"bonjour bateau\r\n");
		
	// Init plateau
	initPlato(TIM3,3);
	Init_IT_Receive(pilotage);
	
	
  // Init lacheurVoile
	initAccelo();
	initServo(TIM4, 3);

  //Init RTC
  //initRTC();
  //getTime();
	
  // ----- Opération -----
	while(1){
		// Girouette
    angleVentVar = angleVent(TIM2); // Récupérer l'angle de girouette
    angleVoileVar = vent2voile(angleVentVar); // Transformer l'angle de girouette au l'angle des voiles souhaités
    Servo_Moteur(angleVoileVar, TIM4, 3); // Faire bouger le moteur servo
		
		// Acceleromètre
		moyenne[i] = RecupAccelo()[2]; // Récuperation et ajout de la valeur plus récente dans le tableau dans la position i
		i++; if (i >= LONGUEUR_MOY) {i = 0;} // Géstion de la position i dans le tableau pour la moyenne glissante
		sum = 0; for (int j = 0; j < LONGUEUR_MOY; j++){sum += moyenne[j];} moy = sum / LONGUEUR_MOY; // Calcul de la moyenne glissante
    LacheVoile(ANGLE_LIMITE, (uint16_t) moy); // Lache la voile si le bateau dépasse l'angle limite
	
    // ADC
    sendinfoADC();
  }
}

