#include <stm32f10x.h>
void initI2C();