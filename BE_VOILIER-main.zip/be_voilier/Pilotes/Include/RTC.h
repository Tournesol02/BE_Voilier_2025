#ifndef RTC_H_
#define RTC_H_
#include <stm32f10x.h>
void initRTC();
int getTime();


#endif // RTC_H_
